#!/usr/bin/env python3
"""把一份 nominal 分镜做成合格成片：TTS 重排 → 混音 → 出片 → 总览 → 验收。

只编排仓内工具，不复制渲染代码。所有 Python 调用走 uv；ffmpeg/ffprobe 走
/opt/homebrew/bin（非交互 shell 不加载 .zshrc）。

用法：
  uv run python make_film.py --repo /path/to/motiongit-lab \
      --preset desktop-kit/presets/hotpot.json --music /path/to/cc0.wav \
      --presenter edits/assets/presenter.png

  --dry-run  只打印将执行的命令，不写任何文件
  --skip-tts 复用已有 -voiced.json 与干声（改了版式但没改文案时用）
  --no-music 只用干声旁白
"""

from __future__ import annotations

import argparse
import json
import os
import shlex
import shutil
import subprocess
import sys
from pathlib import Path

DEFAULT_REPO = Path(
    os.environ.get("MOTIONGIT_REPO",
                   "/Users/macstudio/WorkBuddy/2026-11-08-21-08-09/motiongit-lab")
)

REQUIRED = [
    "desktop-kit/tools/build-voices.py",
    "desktop-kit/tools/render-bench.mjs",
    "desktop-kit/tools/contact.py",
    "desktop-kit/verify.mjs",
    "qa-gate.py",
    "skia-kit/gate.mjs",
]


def env_with_paths() -> dict:
    env = os.environ.copy()
    home_bin = str(Path.home() / ".local/bin")
    env["PATH"] = home_bin + ":/opt/homebrew/bin:" + env.get("PATH", "")
    return env


def run(cmd: list, dry: bool, cwd: Path, env: dict, label: str = "", quiet: bool = False):
    print("+ " + " ".join(shlex.quote(str(c)) for c in cmd), flush=True)
    if dry:
        return ""
    r = subprocess.run([str(c) for c in cmd], cwd=cwd, env=env,
                       text=True, capture_output=True)
    if r.returncode != 0:
        tail = (r.stderr or "")[-1800:] or (r.stdout or "")[-600:]
        raise SystemExit(f"FAIL [{label or cmd[0]}] exit={r.returncode}\n{tail}")
    if not quiet and r.stdout:
        lines = [x for x in r.stdout.strip().splitlines() if x.strip()]
        for line in lines[-8:]:
            print("    " + line, flush=True)
    return r.stdout or ""


def resolve(p: str, repo: Path) -> Path:
    q = Path(p)
    return q if q.is_absolute() else repo / q


def probe_duration(ffprobe: str, f: Path, env: dict) -> float:
    r = subprocess.run([ffprobe, "-v", "error", "-show_entries", "format=duration",
                        "-of", "csv=p=0", str(f)], text=True, capture_output=True, env=env)
    if r.returncode != 0:
        raise SystemExit(f"ffprobe 读不到时长: {f}\n{r.stderr}")
    return float(r.stdout.strip())


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--repo", default=str(DEFAULT_REPO))
    ap.add_argument("--preset", required=True, help="nominal 分镜 JSON（相对 repo 或绝对）")
    ap.add_argument("--name", default=None, help="输出 stem，默认取 preset 文件名")
    ap.add_argument("--music", default=os.environ.get("CC0_MUSIC"),
                    help="CC0 配乐文件；不提供则出干声片")
    ap.add_argument("--no-music", action="store_true")
    ap.add_argument("--presenter", default=None, help="摄像头窗口人像（相对 repo 或绝对）")
    ap.add_argument("--rate", default="+6%")
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--bg", default="gpu", choices=["static", "gpu", "js"])
    ap.add_argument("--pipe", default="raw", choices=["jpeg", "raw"])
    ap.add_argument("--cols", type=int, default=4)
    ap.add_argument("--cell", type=int, default=400)
    ap.add_argument("--ffmpeg", default=None)
    ap.add_argument("--ffprobe", default=None)
    ap.add_argument("--skip-tts", action="store_true")
    ap.add_argument("--skip-h265", action="store_true")
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()

    repo = Path(a.repo).resolve()
    preset = resolve(a.preset, repo)
    if not preset.exists():
        raise SystemExit(f"分镜不存在: {preset}")
    missing = [f for f in REQUIRED if not (repo / f).exists()]
    if missing:
        raise SystemExit("产线仓库缺少文件（用 --repo 指定正确路径）:\n  " + "\n  ".join(missing))

    stem = preset.stem
    voiced_stem = stem[:-7] if stem.endswith("-voiced") else stem
    name = a.name or voiced_stem
    voiced = repo / "desktop-kit/presets" / f"{voiced_stem}-voiced.json"
    dry_audio = repo / "edits" / f"audio-{voiced_stem}.m4a"
    mix_audio = repo / "edits" / f"audio-{name}-mix.m4a"
    out_mp4 = repo / "out" / f"{name}.mp4"
    out_h265 = repo / "out" / f"{name}-h265.mp4"
    contact = repo / "out" / f"{name}-contact.jpg"
    build_json = repo / "out" / f"{name}-build.json"

    env = env_with_paths()
    ffmpeg = a.ffmpeg or shutil.which("ffmpeg", path=env["PATH"]) or "/opt/homebrew/bin/ffmpeg"
    ffprobe = a.ffprobe or shutil.which("ffprobe", path=env["PATH"]) or "/opt/homebrew/bin/ffprobe"
    dry = a.dry_run

    # 1) TTS + 逐句时长重排
    if not a.skip_tts:
        if stem.endswith("-voiced"):
            raise SystemExit("传入的是 voiced 分镜；请给 nominal 分镜，或加 --skip-tts")
        run(["uv", "run", "python", "desktop-kit/tools/build-voices.py",
             "--preset", str(preset), "--rate", a.rate],
            dry, repo, env, "build-voices")

    # 2) 时长 / 帧数 / 淡出点
    if dry and not voiced.exists():
        dur, frames = float("nan"), 0
        print(f"  [dry-run] {voiced} 尚不存在，时长按 nominal 估算占位")
    else:
        if not voiced.exists():
            raise SystemExit(f"voiced 分镜不存在: {voiced}（先跑 TTS 或检查 --preset）")
        d = json.loads(voiced.read_text())
        dur = float(d["durationSeconds"])
        frames = round(dur * float(d.get("fps", 60)))
    fade = round(dur - 3.1, 3) if dur == dur else 0.0

    # 3) 音轨：有 CC0 就混音，没有就干声
    music = None if a.no_music else (Path(a.music).resolve() if a.music else None)
    if music and not music.exists():
        print(f"  [warn] 配乐不存在，改用干声: {music}")
        music = None
    audio = dry_audio
    if music and not dry:
        mdur = probe_duration(ffprobe, music, env)
        if mdur >= dur:
            chain = (f"[1:a]atrim=0:{dur},asetpts=N/SR/TB,"
                     f"volume=-13dB,afade=t=in:st=0:d=1.5,"
                     f"afade=t=out:st={fade}:d=3.1[m]")
        else:
            chain = (f"[1:a]atrim=0:{mdur},asetpts=N/SR/TB[a1];"
                     f"[1:a]atrim=0:{mdur},asetpts=N/SR/TB[a2];"
                     f"[a1][a2]acrossfade=d=2:c1=tri:c2=tri,atrim=0:{dur},"
                     f"volume=-13dB,afade=t=in:st=0:d=1.5,"
                     f"afade=t=out:st={fade}:d=3.1[m]")
        fc = chain + (";[0:a]aformat=sample_rates=48000:channel_layouts=stereo[v];"
                      "[m]aformat=sample_rates=48000:channel_layouts=stereo[mm];"
                      "[v][mm]amix=inputs=2:duration=first:normalize=0[a]")
        run([ffmpeg, "-hide_banner", "-loglevel", "error", "-y",
             "-i", str(dry_audio), "-i", str(music),
             "-filter_complex", fc, "-map", "[a]", "-t", str(dur),
             "-c:a", "aac", "-b:a", "192k", str(mix_audio)],
            dry, repo, env, "mix", quiet=True)
        audio = mix_audio
    elif music and dry:
        audio = mix_audio

    # 4) 出片
    render = ["node", "desktop-kit/tools/render-bench.mjs",
              "--preset", str(voiced), "--bg", a.bg, "--pipe", a.pipe,
              "--audio", str(audio), "--workers", str(a.workers),
              "--out", str(out_mp4), "--json", str(repo / "out" / f"{name}.json")]
    if a.presenter:
        render += ["--presenter", str(resolve(a.presenter, repo))]
    run(render, dry, repo, env, "render")

    # 5) 总览
    run(["uv", "run", "--with", "pillow", "python", "desktop-kit/tools/contact.py",
         "--video", str(out_mp4), "--params", str(voiced), "--out", str(contact),
         "--cols", str(a.cols), "--cell", str(a.cell)], dry, repo, env, "contact")

    # 6) H.265 小体积变体
    if not a.skip_h265:
        run([ffmpeg, "-hide_banner", "-loglevel", "error", "-y",
             "-i", str(out_mp4), "-c:v", "libx265", "-crf", "24", "-preset", "fast",
             "-tag:v", "hvc1", "-c:a", "copy", "-movflags", "+faststart", str(out_h265)],
            dry, repo, env, "h265", quiet=True)

    # 7) 验收：QA / 门禁 / 自检
    run(["uv", "run", "--with", "numpy", "--with", "pillow", "python", "qa-gate.py",
         "--video", str(out_mp4), "--expect-frames", str(frames)],
        dry, repo, env, "qa-gate")
    run(["node", "skia-kit/gate.mjs", str(out_mp4)], dry, repo, env, "gate")
    run(["node", "desktop-kit/verify.mjs"], dry, repo, env, "verify", quiet=False)

    summary = {
        "name": name, "preset": str(preset), "voiced": str(voiced),
        "duration": dur, "frames": frames, "fadeOut": fade,
        "pipeline": f"{a.bg}/{a.pipe}", "workers": a.workers,
        "music": str(music) if music else None,
        "audio": str(audio), "video": str(out_mp4),
        "h265": None if a.skip_h265 else str(out_h265),
        "contact": str(contact),
        "note": "总览必须逐格目视复核；QA/门禁全绿不等于画面可读。",
    }
    print("\n=== 汇总 ===")
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    if not dry:
        build_json.parent.mkdir(parents=True, exist_ok=True)
        build_json.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
        print(f"\n写入 {build_json}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
