# 管线选型与性能口径

数据来源：`motiongit-lab/MOTIONGIT-PLAYBOOK.md` §41–§46、`desktop-kit/README.md`、`out/cmp-report.html`。所有数字为 1440×1080@60、8 worker、同一台机器的实测值。

## 五条管线，同一条分镜

分镜 `desktop-kit/presets/cmp-voiced.json`：6 镜 / 3 章 / 2 次整屏翻牌转场 / 1419 帧 / 23.658s / 同一条音轨。轴拆成**壁纸层 × 传帧**，只换一个变量。

| 变体 | 壁纸层 | 传帧 | 墙钟 | 吞吐 | 单帧绘制 | 单帧传帧 | 体积 |
|---|---|---|---|---|---|---|---|
| A 现状 | Skia 渐变 | JPEG q94 | 7.51s | 188.8 fps | 2.89 ms | **28.77 ms** | 3.76 MB |
| B | Skia 渐变 | RAW | 6.75s | 210.3 | 2.73 | 24.22 | 2.95 |
| C | GPU 流体 | JPEG q94 | 7.28s | 195.1 | 5.03 | 12.80 | 2.82 |
| D | JS 流体 | JPEG q94 | 40.23s | 35.3 | **175.42** | 13.51 | 2.52 |
| E 综合 | GPU 流体 | RAW | 7.27s | 195.2 | 4.15 | 12.40 | 2.69 |

三条结论：

1. **传帧占 A 单帧预算的 91%**（28.77 / 31.66），瓶颈不在绘制。以 `x264 -crf 0` 无损片为基准，A 的 Y-SSIM 0.9728 / 43.22 dB，B 是 0.9772 / 43.77 dB ⇒ 少一次 JPEG＝更快 + 更小 + 更准。
2. **GPU 对静态壁纸一定是亏的**：GPU 壁纸层 3.02 ms（draw 0.79 + readPixels 2.24），内置 Skia 渐变 0.05–0.16 ms。GPU 值钱的只有 CPU 做不到的事：同一段 fBm 流体，JS 逐像素 163.94 ms，GPU 3.02 ms（54×）。
3. **体积主要由壁纸内容决定，不由引擎决定**：同 UI 同动作，壁纸从固定噪点换成低频流体，3.76 MB → 2.52 MB。x264 的码率主要花在高频细节上。

## 质量矩阵（SSIM Y / PSNR）

| 组合 | 比什么 | SSIM Y | PSNR |
|---|---|---|---|
| A ↔ B | 换传输 | 0.9473 | 41.52 dB |
| C ↔ D | 换引擎（同公式） | 0.9869 | 30.49 dB |
| A ↔ C | 换壁纸内容（本就不同） | 0.8843 | 30.27 dB |
| E ↔ C | 综合 vs 仅换引擎 | 0.9948 | 46.48 dB |

## 编码蒸馏（源 = E，2.69 MB）

| 编码 | 体积 | 备注 |
|---|---|---|
| H.264 crf20 | 2.17 MB | 兼容优先，主交付 |
| H.265 crf24 | **1.38 MB** | 小体积变体，`-tag:v hvc1` |
| VP9 crf34 | 1.41 MB | — |
| AV1 svt crf32 | 1.89 MB | **反而比 H.265 大** |

同一 CRF 不等于同一质量，跨编码器不能直接比较 CRF。

## 性能口径（报数时用对定义）

- **帧数** = `round(durationSeconds * fps)`，与 `qa-gate.py --expect-frames` 保持一致，不要手算。
- **吞吐** = 帧数 / 有效出片墙钟。**墙钟与有效渲染要分开报**：`cinecode` 的 `capture.mjs` 写完视频后不退出，墙钟会比日志多 5 分钟量级。
- **同一支片三条管线的量级**（46.386s / 约 2800 帧 / 60fps）：film-kit 官方 mac-desktop 51s / 55 fps / 24.4 MB；skia-kit 6.8s / 409 fps / 3.26 MB；cinecode 113.3s / 24.6 fps / 6.13 MB。
- cinecode 必须 `--flags "--no-sandbox"`，且 PATH 含 `/opt/homebrew/bin`（它 spawn ffmpeg）。
- 三条都能过 `skia-kit/gate.mjs`；但 cinecode 自带的 40px 字高与 hook 0.5 阈值**不可移植**。

## 外部依赖与边界

- `headless-gl`（stack-gl 8.1.6）是原生模块，装在仓外（`/tmp/gl-probe`）。脚本用 `HEADLESS_GL` 兜底查找；换机器需 `npm i gl` 且系统 OpenGL 可用。Chrome 自带 sandbox 在本机起不来时，用 `~/.local/bin/mg-chrome` 包一层 `--no-sandbox`。
- RAW 管道每帧 6.2 MB，整片约 8.8 GB 过管道，**只在本地进程间成立**；跨机器或落盘回退压缩格式。
- 配乐 `api music-prepare` 是 0 积分（CC0 曲目 + 按目标时长裁剪），不要为配乐去调付费 TTS/生图。
- 不要复制渲染器或工具脚本到 skill；单一来源是 `motiongit-lab/desktop-kit/`。

## 手工分步命令（无脚本时复现）

```bash
export PATH="$HOME/.local/bin:/opt/homebrew/bin:$PATH"
cd <repo>
P=desktop-kit/presets/<name>.json
NAME=<name>

# 1) TTS + 按真实句长重排 → <name>-voiced.json / edits/audio-<name>.m4a
uv run python desktop-kit/tools/build-voices.py --preset "$P" --rate +6%

# 2) 动态算时长 / 帧数 / 淡出点
DUR=$(uv run python -c "import json;print(json.load(open('desktop-kit/presets/${NAME}-voiced.json'))['durationSeconds'])")
FR=$(uv run python -c "import json;print(round(json.load(open('desktop-kit/presets/${NAME}-voiced.json'))['durationSeconds']*60))")
FO=$(uv run python -c "print(round($DUR-3.1,3))")
MDUR=$(ffprobe -v error -show_entries format=duration -of csv=p=0 <cc0.wav>)

# 3) 混音：CC0 轨短于成片时两份 acrossfade 拼接；-13dB，片头 1.5s 淡入、片尾 3.1s 淡出
ffmpeg -hide_banner -loglevel error -y -i edits/audio-${NAME}.m4a -i <cc0.wav> \
  -filter_complex "[1:a]atrim=0:${MDUR},asetpts=N/SR/TB[a1];[1:a]atrim=0:${MDUR},asetpts=N/SR/TB[a2];[a1][a2]acrossfade=d=2:c1=tri:c2=tri,atrim=0:${DUR},volume=-13dB,afade=t=in:st=0:d=1.5,afade=t=out:st=${FO}:d=3.1[m];[0:a]aformat=sample_rates=48000:channel_layouts=stereo[v];[m]aformat=sample_rates=48000:channel_layouts=stereo[mm];[v][mm]amix=inputs=2:duration=first:normalize=0[a]" \
  -map "[a]" -t "$DUR" -c:a aac -b:a 192k edits/audio-${NAME}-mix.m4a

# 4) 出片（最优组合）
node desktop-kit/tools/render-bench.mjs --preset desktop-kit/presets/${NAME}-voiced.json \
  --bg gpu --pipe raw --audio edits/audio-${NAME}-mix.m4a \
  --presenter <肖像png> --workers 8 --out out/${NAME}.mp4 --json out/${NAME}.json

# 5) 总览 / H.265 / 验收
uv run --with pillow python desktop-kit/tools/contact.py --video out/${NAME}.mp4 \
  --params desktop-kit/presets/${NAME}-voiced.json --out out/${NAME}-contact.jpg --cols 4 --cell 400
ffmpeg -hide_banner -loglevel error -y -i out/${NAME}.mp4 -c:v libx265 -crf 24 -preset fast \
  -tag:v hvc1 -c:a copy -movflags +faststart out/${NAME}-h265.mp4
uv run --with numpy --with pillow python qa-gate.py --video out/${NAME}.mp4 --expect-frames "$FR"
node skia-kit/gate.mjs out/${NAME}.mp4
node desktop-kit/verify.mjs
```

`render-bench.mjs` 可选参数：`--bg static|gpu|js`、`--pipe jpeg|raw`、`--crf`、`--x264`、`--jpeg`、`--limit`、`--probe <png> --at <秒>`、`--presenter`、`--workers`、`--json`。
