# 分镜、文案、音轨与素材

## preset 结构

```jsonc
{
  "fps": 60,
  "durationSeconds": 57.0,          // nominal 值，voiced 会按真实句长重排
  "brand": "...",
  "chapters": [{ "name": "01 起站", "wall": "blue" }],   // wall: blue | light | orange | red
  "shots": [
    { "type": "title", "t0": 0, "t1": 5, "chapter": "01 起站", "args": { /* ... */ } }
  ],
  "captions": [
    { "start": 0.12, "end": 4.9, "zh": "今晚这顿，*锅先开*。", "en": "The pot comes first." }
  ],
  "photos": { "mine": "edits/assets/hotpot/my-photo.jpg" },
  "clips":  { "boil": { "dir": "edits/assets/hotpot/clips/boil", "fps": 20 } }
}
```

- `shots` 与 `captions` **一一对应**；`chapter` 变化触发整屏翻牌转场；`wall` 决定壁纸与明暗。
- `captions[].zh` 里的 `*词*` 渲染成黄色强调，中文逐字揭示，英文整句跟随。长文案按安全宽度整体缩号，绝不裁字。
- 未知镜头类型**硬失败**。写完用 `node --input-type=module -e 'import { validateParams } ...'` 校验；`validateParams` 由 `setContent` 与 `loadParams` 共用，出片前也会再验一次。
- 顶层 `photos` / `clips` 会被 `build-voices.py` 原样保留到 `-voiced.json`。

**镜头类型与 `args` 契约的单一来源是 `desktop-kit/desktop.mjs` 的 `SHOTS` 对象**（16 个纯组件 + `photo` + `clip`）。写分镜前读该文件相关函数，不要凭记忆猜字段名；尤其 `tickets.price`、`ranking.rows`、`comments.items`、`counter.value`、`terminal.lines`、`outro.lines` 的长度/字数会触发不同布局。已实测的字数限制：

- `title.headline` 5 字以内（翻牌块自动收窄保总宽 ≤400px）。
- `flipBoard.word` 3–4 字（118px/块，板宽 720px）。
- `ranking.rows` 每行 ≤4 字（78px/字）。
- `tickets.price` ≤3 字；带空格会产生空白翻牌块（「8 项」→ 改「8项」）。
- `comments.items` 最多渲 12 张，每条 ≤45 字（3 行 × 15 字），第 12 张可设 `hi: true` 做强调。
- `outro.lines` 3 行以内，超过会压到 CTA 按钮。

## 文案纪律

- **数字必须有出处**。城市介绍片核过：明城墙全长 35.267 km / 现存 25.091 km（市文旅局）、2024 年末常住人口 957.70 万、地铁 15 条线 483.3 km（统计公报）。技术片只用本仓实测值，不写没有依据的倍数。
- **健康类**：口径取 ACOG / NHS / 默沙东 / 权威医典；片尾明确写「科普内容，不替代医生判断」，品牌位标资料来源；来源内部自相矛盾的条目（如「补钙」）回避而非选边。
- **典型病程不写成人群比例**（「多数人」→「通常」）；无坐标轴的折线图标注「示意」，避免插画被读成统计曲线。
- **生活/氛围片不硬塞数据**：用叙事日志、点单列表、票券、翻牌承载节奏，不写未经核实的烹饪时间或民间说法当结论。
- 站牌副标题不要与字幕重复（两处同时出现会显得冗余）。

## 音轨

- `build-voices.py`：`--preset`、`--rate`（常用 +6% / +8%）、`--gap 0.42`、`--lead 0.35`、`--tail 2.8`、`--voice zh-CN-XiaoxiaoNeural`。按真实句长重排镜头边界 ⇒ **音画天然对齐**，不需要手工卡点。输出 `<stem>-voiced.json` 与 `edits/audio-<stem>.m4a`。
- 改任何一句文案都要**重跑 TTS**：时长变化会牵动整条时间轴、帧数、淡出点与混音长度。
- 配乐：CC0 轨压到 **-13 dB**（比人声低约 9 dB），片头 1.5s 淡入、片尾 3.1s 淡出；轨短于成片时取两份 `acrossfade=d=2:c1=tri:c2=tri` 拼接再 `atrim`。整轨峰值实测约 -5～-6 dB，不削顶。`amix` 用 `normalize=0`，否则人声会被自动拉低。
- 交付前用 `ffmpeg -af volumedetect` 核对峰值。

## 素材通路（本机实测连通性）

| 来源 | 状态 |
|---|---|
| `commons.wikimedia.org` / `upload.wikimedia.org` | 20s 超时不可达；`wsrv.nl` 代理被上游 429 |
| `images.pexels.com` / `images.unsplash.com` / `cdn.pixabay.com` | 直连 200，<2s |
| `videos.pexels.com` | 直连可用；`player.vimeo.com` 不通 |

流程：

1. `WebFetch` 抓 Pexels 搜索页，提取 `images.pexels.com/photos/<id>/...` 直链；排除 iStock / Getty 赞助位。
2. 下载：`curl "https://images.pexels.com/photos/<id>/pexels-photo-<id>.jpeg?auto=compress&cs=tinysrgb&w=2000"`。
3. 视频：`curl -sSI "https://www.pexels.com/download/video/<id>/"` 取 302 `Location`（常见 4K），**不整条下载**，用 `ffmpeg -ss N -t 2.5 -i <url> -vf "scale=1280:-2,fps=20" -q:v 3 <dir>/f%03d.jpg` 按区间远程抽帧（约 50 帧 / 5 MB）。
4. 竖幅图（2:3）用 `photo` 的 `layout: window`（520×700 contain）；横幅且主体居中的才用 `full`。竖幅视频铺 4:3 会切掉主体，排除。
5. 逐张 `ViewImage` 核验：无水印、无可读品牌文字、内容确实相关、色调与用户实拍一致。

**许可**：Pexels 免费许可，可商用、无需署名。仍在画面角标与 preset 路径里保留来源——「不需要署名」不等于「可以不留痕」。用户自己的照片标「本人实拍」。

## 语义对抗审查（选素材时）

- 健康片初选的「散落药片 + 体温计 + 药板」静物会被读成随意服药，与「按说明、有禁忌人群」冲突 ⇒ 弃用，改中性静物（书+热茶+白毯、日历+笔）。
- 商业摆拍（黑底 + 干辣椒 + 酒坛）与家庭实拍风格不搭；黑白素材与彩色实拍色调不统一 ⇒ 弃用。
- 视频里出现陌生人时优先选**无正脸**的（只见手/衣角）；不使用可识别肖像。
- 素材语义要与同镜文案一致：配图是热饮就把文案从「热敷」改成「休息」，不要图文各说各话。

## photo / clip 参数

```json
{ "type": "photo", "t0": 9, "t1": 14,
  "args": { "key": "mine", "layout": "full", "title": "这一桌", "sub": "...",
            "credit": "本人实拍", "fx": 0.5, "fy": 0.48 } }
{ "type": "clip", "t0": 23, "t1": 27,
  "args": { "key": "boil", "fps": 20, "title": "锅在滚", "sub": "...",
            "credit": "Pexels 素材", "fx": 0.5, "fy": 0.5 } }
```

- `full`：全屏 cover + 慢推 1.05→1.12（`photo` 才有；`clip` 不叠推镜）+ 底部压暗 + 顶部压暗。
- `window`：相框卡片 contain，竖图不裁主体；标题/副标题画在卡片下方，不要设 `sub` 以免贴到字幕带。
- 右下角来源角标放 `H-50`，避开 `H-24` 的品牌文字。
- **缺素材硬失败**（`没有注入素材` / `没有注入帧序列`），不画空白；`verify.mjs` 有专门负向断言。
- `clip` 必须按区间加载帧序列：8 进程全载约 2.9 GB，按区间过滤后只有覆盖该段的 1–2 个进程加载（≈184 MB）。
- 左上角红点 + `00:02.15` 时间码是刻意保留的，用来标明「这是实拍素材不是生成静帧」。

## 人像摄像头窗口

- 默认程序化占位是刻意的（避免误用他人肖像）；用户要真人感时用生成图，**不要**找真人照片。
- 生成图右下角常有平台水印，cover 裁切不会自动避开 ⇒ 先裁掉底部约 150px 再交给 `--presenter`。
- 摄像头窗口 378×568（2:3），`--presenter` 用 cover 裁切；生成图按 2:3 竖幅、上半身、正脸、留足头顶空间。
- 生活片里该窗口会略显「视频会议」感；保留版式一致性与去掉它之间要如实告知用户，让其选择。
