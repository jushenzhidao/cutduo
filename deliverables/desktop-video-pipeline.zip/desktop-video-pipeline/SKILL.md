---
name: desktop-video-pipeline
version: 1.0.0
display_name: 桌面版式视频产线
display_name_en: Desktop Video Pipeline
description: 把一份 JSON 分镜做成 1440×1080@60 的成片（Mac Desktop 版式、双语逐字字幕、TTS 旁白、配乐、可选实拍照片与视频片段），并跑完交付验收。当用户说「剪个视频」「做一支片子」「出片」「换个文案重出」「加图/视频素材」「做个 XX 介绍视频」「对比几条渲染管线」，或提到 desktop-kit、分镜 preset、翻牌镜头、逐字字幕时触发。内含最优管线选型、音画重排命令、Pexels 素材许可口径、字幕对比度与合成后明暗判据、门禁清单，以及一键编排脚本 make_film.py。不用于文生视频/图生视频，也不用于把已有素材剪辑成片（那些走生成式视频或剪辑能力）。
agent_created: true
---

# 桌面版式视频产线

把一个 JSON 分镜变成合格成片：Skia 画 UI 与文字、GPU 着色器画流动氛围、裸帧传给 ffmpeg、8 进程分片编码、TTS 按真实句长重排时间轴，最后跑完整验收。所有规则来自同一条产线上多支片子的实测，不是体感。

## 不可协商的四条原则

1. **只接受实测对照，不接受体感。** 比较两条管线时，固定同一份分镜、同一条音轨、同一分辨率帧率，只换一个变量；报告出片墙钟、吞吐、体积、重复帧四项，不以「看着更快」下结论。
2. **判据针对合成后的像素，不针对素材像素。** 字幕墨色、明暗、可读性，都要看最终叠加了压暗/描边之后的画面。原素材亮度是无效判据（见 `references/gates.md`）。
3. **「看起来差不多」不算通过。** 指定一个可计算的区域（如纯壁纸区）+ 一个可计算的统计量（均值、高频能量、对比度），否则会陷入无止境调参。
4. **只有交付完整性可以当门禁。** 风格类指标（开场运动、亮度、重复帧比例）只报不拦，阈值照搬其它项目会误杀口播片（见 `references/gates.md`）。

## 0. 前置检查

执行以下检查，任一失败先修正环境，不要带病出片：

- 定位产线仓库：默认 `/Users/macstudio/WorkBuddy/2026-11-08-21-08-09/motiongit-lab`；不存在时用 Glob 搜 `**/desktop-kit/render.mjs` 找到实际根目录，后续全部用该绝对路径。
- 确认 `desktop-kit/verify.mjs`、`tools/render-bench.mjs`、`tools/build-voices.py`、`tools/contact.py`、`qa-gate.py`、`skia-kit/gate.mjs` 均存在。
- 命令前统一 `export PATH="$HOME/.local/bin:/opt/homebrew/bin:$PATH"`：非交互 shell 不加载 `.zshrc`，`uv` 与 `ffmpeg` 都会找不到；Python 一律 `uv run`，禁止 pip / `python -m venv`。
- 检查配乐素材：CC0 音轨需自备；不提供则出干声片（`--no-music`），不硬编码临时目录路径。

## 1. 判定任务类型

| 用户诉求 | 入口 |
|---|---|
| 新主题 / 换文案 | 写 nominal preset → 完整流程（第 2–6 步） |
| 只改几处文案、重出 | 改 preset → 直接跑 `make_film.py`（必须重跑 TTS，时间轴会变） |
| 加实拍图 / 视频素材 | 读 `references/content.md` 的素材通路，加 `photo` / `clip` 镜头 |
| 改版式 / 调组件 | 先用单帧探针回路，确认后再全片出 |
| 比较渲染管线 | 读 `references/pipeline.md`，固定分镜只换 `--bg` / `--pipe` |

## 2. 写 nominal preset

在 `desktop-kit/presets/<name>.json` 写 `fps`、`durationSeconds`、`brand`、`chapters`、`shots`、`captions`；素材另写在顶层 `photos` / `clips`。`shots` 与 `captions` 一一对应，未知镜头类型必须硬失败而非静默降级。写完先跑 `validateParams` 校验。字段契约、文案纪律与素材许可详见 `references/content.md`。

**镜头类型与 `args` 的单一来源是仓内 `desktop-kit/desktop.mjs` 的 `SHOTS` 对象**；不要在 skill 里维护一份参数表副本，需要时读该文件。

## 3. 探针帧（改版式的最短回路）

```bash
node desktop-kit/tools/render-bench.mjs --preset <nominal.json> \
  --bg gpu --probe /tmp/probe.png --at <秒> --presenter <肖像png>
```

按 nominal 时间轴取每类镜头的中点渲一帧，逐帧检查文字溢出、遮挡、字幕对比度、相框裁切。全片出片前必须先过这一关。

## 4. 一键出片与验收

优先用 `scripts/make_film.py`，它把「TTS 重排 → 计算帧数与淡出点 → 配乐混音 → 8 worker 出片 → 总览 → QA → 门禁 → H.265」串成一条可复现命令：

```bash
uv run python <skill>/scripts/make_film.py \
  --repo /path/to/motiongit-lab \
  --preset desktop-kit/presets/<name>.json \
  --music /path/to/cc0.wav \
  --presenter edits/assets/presenter.png \
  --workers 8
```

支持 `--dry-run`（只打印命令）、`--skip-tts`（复用已有 voiced 分镜与干声）、`--no-music`、`--bg/--pipe`（对比测试）、`--name`（输出 stem）。脚本每步硬失败即停，并写 `out/<name>-build.json` 汇总。

手工分步命令与每个参数的含义见 `references/pipeline.md`。

## 5. 视觉复核（不可跳过）

1. 用 `tools/contact.py` 生成全片总览，逐格检查黑屏、空镜、豆腐块、文字溢出、字幕压 Dock。
2. 对总览里可疑的格子**按 voiced 真实时间轴**抽原尺寸帧并 1:1 裁切放大。缩略图会把翻牌入场中途误判成缺字、把计数器字间距误判成空白块。
3. 检查每个全屏照片/视频镜的字幕是否可读，浅灰壁纸上的裸文字是否为深墨色。

## 6. 交付

- 跑 `verify.mjs`（渲染器自检）、`qa-gate.py --expect-frames <round(duration*60)>`、`skia-kit/gate.mjs`，三者全绿才算完成；`hook` 告警属开场静态标题固有特征，如实写明但不判失败。
- 产出主片（H.264，兼容优先）+ H.265 小体积变体 + 总览图，用 `present_files` 交付。
- 如实列出边界：RAW 管道只在本地进程间成立、视频片段为 20fps 抽帧有轻微上采样、人像为生成图、素材来源与许可。

## 硬性决策表

| 情境 | 决策 | 依据 |
|---|---|---|
| 默认出片 | `--bg gpu --pipe raw` + H.264 crf20 | 少一次 JPEG＝更快+更小+更准，三项同向 |
| 只要静态渐变壁纸 | `--bg static` | GPU 层 3.02ms vs Skia 0.05–0.16ms，静态上 GPU 必亏 |
| 需要流动氛围 | 必须 GPU | 同一段 fBm：JS 163.94ms vs GPU 3.02ms（54×） |
| 跨机器 / 落盘传输帧 | 回退 `--pipe jpeg` | RAW 每帧 6.2MB，整片约 8.8GB 过管道 |
| 在意体积且设备可播 H.265 | 转 `libx265 -crf 24 -tag:v hvc1` | 实测约 0.6×；AV1 同 CRF 反而更大，不可直接比 CRF |
| 竖幅素材 | `photo` 用 `layout: window` | 直接铺 4:3 会切掉主体 |
| 真实视频素材 | `clip` + 预抽帧，且必须按区间加载 | 8 进程全载约 2.9GB；不叠 Ken Burns（画面本身在动） |
| 健康 / 数据类文案 | 每个数字查出来源 + 片尾免责 | 「看起来专业、其实说错」比渲染缺陷更严重 |

## 资源索引

- `references/pipeline.md` — 五条管线实测、性能口径、编码蒸馏、外部依赖
- `references/gates.md` — 门禁标定、字幕对比度、合成后明暗判据、验收命令
- `references/content.md` — 分镜结构、文案纪律、TTS/混音、素材通路与许可
- `references/pitfalls.md` — 高频踩坑与「缩略图误判」清单
- `scripts/make_film.py` — 一键编排（TTS→混音→出片→验收）

需要改渲染器时，只动仓库里的 `desktop-kit/desktop.mjs` 并跑 `verify.mjs`；**不要**把渲染器或工具脚本复制进 skill，避免两份代码不同步。
